package com.glassremote.domain.model

data class TvDevice(
    val id: String,
    val name: String,
    val host: String,
    val port: Int = 6466,
)

enum class LinkPhase { Idle, Connecting, Ready, Disconnected }

data class RemoteStatus(
    val phase: LinkPhase = LinkPhase.Idle,
    val poweredOn: Boolean? = null,
    val volume: Int? = null,
    val volumeMax: Int? = null,
    val muted: Boolean? = null,
    val error: String? = null,
)

enum class KeyDirection { Short, StartLong, EndLong }
