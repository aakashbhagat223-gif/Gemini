package com.glassremote.data.network

import com.glassremote.data.security.CertificateManager
import com.glassremote.domain.model.LinkPhase
import com.glassremote.domain.model.RemoteStatus
import com.glassremote.proto.remote.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.Closeable
import javax.net.ssl.SSLSocket

/** Live control channel (TCP 6466). Answers the TV's handshake + pings and sends key events. */
class RemoteSession(
    private val certs: CertificateManager,
    private val host: String,
    private val scope: CoroutineScope,
) : Closeable {

    private val _status = MutableStateFlow(RemoteStatus(LinkPhase.Connecting))
    val status: StateFlow<RemoteStatus> = _status.asStateFlow()

    private var socket: SSLSocket? = null
    private var readJob: Job? = null
    private val writeLock = Mutex()

    suspend fun connect() {
        val s = withContext(Dispatchers.IO) { certs.openSocket(host, REMOTE_PORT, soTimeoutMs = 20_000) }
        socket = s
        readJob = scope.launch(Dispatchers.IO) { readLoop(s) }
    }

    private suspend fun readLoop(s: SSLSocket) {
        try {
            while (isActive) handle(Framing.read(s.inputStream, RemoteMessage::parseFrom))
        } catch (t: Throwable) {
            if (isActive) _status.update { it.copy(phase = LinkPhase.Disconnected, error = t.message ?: t.javaClass.simpleName) }
        }
    }

    private suspend fun handle(m: RemoteMessage) {
        when {
            m.hasRemoteConfigure() -> send(RemoteMessage.newBuilder().setRemoteConfigure(
                RemoteConfigure.newBuilder().setCode1(FEATURES).setDeviceInfo(
                    RemoteDeviceInfo.newBuilder()
                        .setModel("GlassRemote").setVendor("GlassRemote")
                        .setUnknown1(1).setUnknown2("1")
                        .setPackageName("com.glassremote").setAppVersion("1.0.0")
                )
            ).build())

            m.hasRemoteSetActive() -> {
                send(RemoteMessage.newBuilder()
                    .setRemoteSetActive(RemoteSetActive.newBuilder().setActive(FEATURES)).build())
                _status.update { it.copy(phase = LinkPhase.Ready, error = null) }
            }

            m.hasRemotePingRequest() -> send(RemoteMessage.newBuilder().setRemotePingResponse(
                RemotePingResponse.newBuilder().setVal1(m.remotePingRequest.val1)).build())

            m.hasRemoteStart() -> _status.update { it.copy(poweredOn = m.remoteStart.started) }

            m.hasRemoteSetVolumeLevel() -> m.remoteSetVolumeLevel.let { v ->
                _status.update {
                    it.copy(volume = v.volumeLevel, volumeMax = v.volumeMax, muted = v.volumeMuted)
                }
            }

            m.hasRemoteError() -> _status.update { it.copy(error = "TV reported an error") }
        }
    }

    suspend fun sendKey(keyCode: Int, direction: RemoteDirection = RemoteDirection.DIRECTION_SHORT) =
        send(RemoteMessage.newBuilder().setRemoteKeyInject(
            RemoteKeyInject.newBuilder().setKeyCode(keyCode).setDirection(direction)).build())

    suspend fun launchApp(deepLink: String) =
        send(RemoteMessage.newBuilder().setRemoteAppLinkLaunchRequest(
            RemoteAppLinkLaunchRequest.newBuilder().setAppLink(deepLink)).build())

    private suspend fun send(m: RemoteMessage) = withContext(Dispatchers.IO) {
        val s = socket ?: error("Not connected")
        writeLock.withLock { Framing.write(s.outputStream, m) }
    }

    override fun close() {
        readJob?.cancel()
        runCatching { socket?.close() }
        _status.update { it.copy(phase = LinkPhase.Disconnected) }
    }

    companion object {
        const val REMOTE_PORT = 6466
        private const val FEATURES = 622 // capability bitmask the TV expects echoed back
    }
}
