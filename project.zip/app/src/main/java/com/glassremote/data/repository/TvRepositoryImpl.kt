package com.glassremote.data.repository

import com.glassremote.data.network.PairingClient
import com.glassremote.data.network.PairingSession
import com.glassremote.data.network.RemoteSession
import com.glassremote.data.network.TvDiscovery
import com.glassremote.data.security.CertificateManager
import com.glassremote.di.AppScope
import com.glassremote.domain.model.KeyDirection
import com.glassremote.domain.model.LinkPhase
import com.glassremote.domain.model.RemoteStatus
import com.glassremote.domain.model.TvDevice
import com.glassremote.domain.repository.TvRepository
import com.glassremote.proto.remote.RemoteDirection
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TvRepositoryImpl @Inject constructor(
    private val discovery: TvDiscovery,
    private val certs: CertificateManager,
    private val store: PairedDeviceStore,
    @AppScope private val scope: CoroutineScope,
) : TvRepository {

    private val _status = MutableStateFlow(RemoteStatus())
    override val status: StateFlow<RemoteStatus> = _status.asStateFlow()

    private var pairing: PairingSession? = null
    private var remote: RemoteSession? = null
    private var statusJob: Job? = null

    override fun discover(): Flow<List<TvDevice>> = discovery.discover()

    override suspend fun beginPairing(device: TvDevice) {
        pairing?.close()
        pairing = PairingClient(certs).begin(device.host)
    }

    override suspend fun submitPairingCode(device: TvDevice, code: String) {
        val s = pairing ?: error("Pairing not started")
        s.submitCode(code)
        s.close(); pairing = null
        store.save(device)
    }

    override suspend fun connect(device: TvDevice) {
        disconnect()
        _status.value = RemoteStatus(LinkPhase.Connecting)
        val session = RemoteSession(certs, device.host, scope)
        remote = session
        statusJob = scope.launch { session.status.collect { _status.value = it } }
        try {
            session.connect()
        } catch (t: Throwable) {
            _status.update { it.copy(phase = LinkPhase.Disconnected, error = t.message) }
            throw t
        }
    }

    override suspend fun sendKey(keyCode: Int, direction: KeyDirection) {
        val dir = when (direction) {
            KeyDirection.Short -> RemoteDirection.DIRECTION_SHORT
            KeyDirection.StartLong -> RemoteDirection.DIRECTION_START_LONG
            KeyDirection.EndLong -> RemoteDirection.DIRECTION_END_LONG
        }
        remote?.sendKey(keyCode, dir)
    }

    override suspend fun launchApp(deepLink: String) { remote?.launchApp(deepLink) }

    override fun disconnect() {
        statusJob?.cancel(); statusJob = null
        remote?.close(); remote = null
    }

    override suspend fun resetPairing() {
        disconnect()
        pairing?.close(); pairing = null
        certs.resetIdentity()
        store.clear()
        _status.value = RemoteStatus()
    }
}
